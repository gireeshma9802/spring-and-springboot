package org.learning;

public class Mars {
 public Mars(){
      System.out.println("Mars is complied.");
 }


}
