package org.learning;

public class Alien {

    public Alien(){
        System.out.println("Alien is compliing");
    }
    public void build() {

        System.out.println( "Hello alien World!" );
    }
}
